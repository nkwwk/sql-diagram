-- customers
CREATE TABLE customers (id INT PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO customers VALUES (1, 'a;b');
