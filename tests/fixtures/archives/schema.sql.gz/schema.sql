-- customers
CREATE TABLE customers (id INT PRIMARY KEY, name TEXT NOT NULL);
INSERT INTO customers VALUES (1, 'a;b');
-- orders
CREATE TABLE orders (id INT PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers(id));
